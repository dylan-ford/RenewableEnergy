﻿/*
 */

using System;
using System.ComponentModel.Design;

namespace Project2RenewableEnergy
{
    class Program
    {
        static void Main(string[] args)
        {
            Helper helper = new Helper();
            helper.Menu();
        }

    }
}
